﻿using Microsoft.AspNetCore.Mvc;

namespace PharmacyStoreManagementSystem.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult Home()
        {
            return View();
        }
    }
}
