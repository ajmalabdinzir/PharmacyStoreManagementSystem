﻿using Microsoft.AspNetCore.Mvc;

namespace PharmacyStoreManagementSystem.Controllers
{
    public class Lndingpge : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
