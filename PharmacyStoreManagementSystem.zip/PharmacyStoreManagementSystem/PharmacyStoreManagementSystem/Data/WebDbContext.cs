﻿using Microsoft.EntityFrameworkCore;
using PharmacyStoreManagementSystem.Models;

namespace PharmacyStoreManagementSystem.date
{
    public class WebDbContext : DbContext
    {
        public WebDbContext(DbContextOptions<WebDbContext> options): base(options)
        {
        }
        public DbSet<Customer>? Customers { get; set; }
        public DbSet<Product>? Products { get; set; }
        public DbSet<Registration>? Registrations { get; set; }
        public DbSet<Sale>? Sales { get; set; }
        public DbSet<SaleItem>? SaleItem { get; set; }
        public DbSet<Users>? Users { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .Property(p => p.Price)
                .HasPrecision(18, 2); // Adjust the precision and scale as needed

            modelBuilder.Entity<Sale>()
                .Property(s => s.TotalAmount)
                .HasPrecision(18, 2); // Adjust the precision and scale as needed

            modelBuilder.Entity<SaleItem>()
                .Property(si => si.Price)
                .HasPrecision(18, 2); // Adjust the precision and scale as needed

            base.OnModelCreating(modelBuilder);
        }

    }
}